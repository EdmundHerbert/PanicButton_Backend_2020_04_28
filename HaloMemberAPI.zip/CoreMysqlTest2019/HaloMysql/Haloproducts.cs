﻿namespace AdminPortal.HaloMysql
{
    public partial class Haloproducts
    {
        public long HaloProductId { get; set; }
        public string HaloProductName { get; set; }
        public string HaloProductIcon { get; set; }
        public string HaloProductDescription { get; set; }
        public string HaloProductTerms { get; set; }
        public decimal? HaloProductPrice { get; set; }
        public string HaloProductPhoneNumber { get; set; }
    }
}
