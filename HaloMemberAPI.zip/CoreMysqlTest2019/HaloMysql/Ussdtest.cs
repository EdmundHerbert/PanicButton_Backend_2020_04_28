﻿namespace AdminPortal.HaloMysql
{
    public partial class Ussdtest
    {
        public int Id { get; set; }
        public string Contents { get; set; }
    }
}
