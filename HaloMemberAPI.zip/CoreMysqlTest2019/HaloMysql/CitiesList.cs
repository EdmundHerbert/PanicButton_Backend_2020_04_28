﻿namespace AdminPortal.HaloMysql
{
    public partial class CitiesList
    {
        public int CitiesListId { get; set; }
        public string CitiesListName { get; set; }
        public string CitiesListDescription { get; set; }
    }
}
