﻿namespace AdminPortal.HaloMysql
{
    public partial class Services
    {
        public int ServiceId { get; set; }
        public int? ProviderId { get; set; }
        public string ServiceName { get; set; }
        public string ServiceDescription { get; set; }
    }
}
