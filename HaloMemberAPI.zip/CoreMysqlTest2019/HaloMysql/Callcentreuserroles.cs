﻿namespace AdminPortal.HaloMysql
{
    public partial class Callcentreuserroles
    {
        public short CallCentreUserRoleId { get; set; }
        public string CallCentreUserRoleName { get; set; }
    }
}
