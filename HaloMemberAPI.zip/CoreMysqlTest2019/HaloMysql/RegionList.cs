﻿namespace AdminPortal.HaloMysql
{
    public partial class RegionList
    {
        public int RegionListId { get; set; }
        public string RegionListName { get; set; }
        public string RegionListDescription { get; set; }
    }
}
