﻿namespace AdminPortal.HaloMysql
{
    public partial class Halomemberftpfiles
    {
        public long HaloMemberFtpFilesId { get; set; }
        public string HaloMemberFtpFilesFileName { get; set; }
        public string HaloMemberFtpFileProcessed { get; set; }
        public string HaloMemberFtpFilesTimeStamp { get; set; }
        public string HaloMemberFtpFolderName { get; set; }
        public string HaloMemberFtpFilesEmailSent { get; set; }
    }
}
