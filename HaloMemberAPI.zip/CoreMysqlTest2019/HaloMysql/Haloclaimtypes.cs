﻿namespace AdminPortal.HaloMysql
{
    public partial class Haloclaimtypes
    {
        public int Id { get; set; }
        public string ClaimType { get; set; }
        public string GroupName { get; set; }
        public string CimsType { get; set; }
    }
}
