﻿namespace AdminPortal.HaloMysql
{
    public partial class ServiceSubCategoriesList
    {
        public int ServiceSubCategoriesListId { get; set; }
        public string ServiceSubCategoriesListName { get; set; }
        public string ServiceSubCategoriesListDescription { get; set; }
    }
}
