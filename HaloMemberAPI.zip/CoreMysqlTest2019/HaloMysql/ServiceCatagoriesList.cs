﻿namespace AdminPortal.HaloMysql
{
    public partial class ServiceCatagoriesList
    {
        public int ServiceCatagoriesListId { get; set; }
        public string ServiceCatagoriesListName { get; set; }
        public string ServiceCatagoriesListDescription { get; set; }
    }
}
