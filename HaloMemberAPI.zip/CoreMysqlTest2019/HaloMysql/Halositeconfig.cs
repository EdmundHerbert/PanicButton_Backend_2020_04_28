﻿namespace AdminPortal.HaloMysql
{
    public partial class Halositeconfig
    {
        public int HaloSiteConfigId { get; set; }
        public string HaloSiteConfigKey { get; set; }
        public string HaloSiteConfigValue { get; set; }
    }
}
