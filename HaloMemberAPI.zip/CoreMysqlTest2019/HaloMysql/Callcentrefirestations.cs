﻿namespace AdminPortal.HaloMysql
{
    public partial class Callcentrefirestations
    {
        public long CallCentreFireStationId { get; set; }
        public string CallCentreFireStationName { get; set; }
        public string CallCentreFireStationAddress { get; set; }
        public string CallCentreFireStationLat { get; set; }
        public string CallCentreFireStationLng { get; set; }
        public string CallCentreFireStationPhoneNumber { get; set; }
    }
}
