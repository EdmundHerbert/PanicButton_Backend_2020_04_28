﻿namespace AdminPortal.HaloMysql
{
    public partial class HaloMobileContentClients
    {
        public int Id { get; set; }
        public int? HaloMobileContentId { get; set; }
        public int? HaloMobileClientId { get; set; }
    }
}
