﻿namespace AdminPortal.HaloMysql
{
    public partial class Halomobileclientcontent
    {
        public long HaloMobileClientContentId { get; set; }
        public long? HaloMobileClientContentClientId { get; set; }
        public string HaloMobileClientContentPageName { get; set; }
        public string HaloMobileClientContentPageContent { get; set; }
    }
}
