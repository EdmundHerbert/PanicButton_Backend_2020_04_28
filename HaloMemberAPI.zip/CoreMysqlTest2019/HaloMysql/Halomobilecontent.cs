﻿namespace AdminPortal.HaloMysql
{
    public partial class Halomobilecontent
    {
        public int HaloMobileContentId { get; set; }
        public string HaloMobileContentPageName { get; set; }
        public string HaloMobileContentPageContent { get; set; }
        public string HaloMobileContentType { get; set; }
    }
}
