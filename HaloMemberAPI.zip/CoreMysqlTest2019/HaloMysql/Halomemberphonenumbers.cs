﻿namespace AdminPortal.HaloMysql
{
    public partial class Halomemberphonenumbers
    {
        public long HaloMemberPhoneNumberId { get; set; }
        public long? HaloMemberId { get; set; }
        public string HaloMemberPhoneNumber { get; set; }
    }
}
