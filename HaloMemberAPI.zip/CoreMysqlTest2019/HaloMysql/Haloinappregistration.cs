﻿namespace AdminPortal.HaloMysql
{
    public partial class Haloinappregistration
    {
        public string MemberId { get; set; }
        public string PlayerId { get; set; }
    }
}
