﻿namespace AdminPortal.HaloMysql
{
    public partial class Cmsuserroles
    {
        public short CmsuserRoleId { get; set; }
        public string CmsuserRoleName { get; set; }
    }
}
