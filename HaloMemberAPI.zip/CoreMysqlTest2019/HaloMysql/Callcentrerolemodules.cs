﻿namespace AdminPortal.HaloMysql
{
    public partial class Callcentrerolemodules
    {
        public int CallCentreRoleModuleId { get; set; }
        public short? CallCentreRoleId { get; set; }
        public short? CallCentreModuleId { get; set; }
    }
}
