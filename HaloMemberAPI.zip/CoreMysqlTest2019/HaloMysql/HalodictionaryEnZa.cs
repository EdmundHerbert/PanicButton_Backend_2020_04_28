﻿namespace AdminPortal.HaloMysql
{
    public partial class HalodictionaryEnZa
    {
        public int Id { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
