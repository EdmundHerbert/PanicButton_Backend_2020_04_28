﻿namespace AdminPortal.HaloMysql
{
    public partial class Halomemberprograms
    {
        public long HaloMemberProgramId { get; set; }
        public long? HaloClientId { get; set; }
        public long? HaloMemberId { get; set; }
        public long? HaloProgramId { get; set; }
    }
}
