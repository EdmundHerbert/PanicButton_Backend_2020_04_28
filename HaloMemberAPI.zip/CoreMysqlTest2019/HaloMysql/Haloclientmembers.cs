﻿namespace AdminPortal.HaloMysql
{
    public partial class Haloclientmembers
    {
        public long HaloClientMemberId { get; set; }
        public long? HaloClientId { get; set; }
        public long? HaloMemberId { get; set; }
    }
}
