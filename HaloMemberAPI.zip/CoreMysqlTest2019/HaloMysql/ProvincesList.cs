﻿namespace AdminPortal.HaloMysql
{
    public partial class ProvincesList
    {
        public int ProvincesListId { get; set; }
        public string ProvincesListName { get; set; }
        public string ProvincesListDescription { get; set; }
    }
}
