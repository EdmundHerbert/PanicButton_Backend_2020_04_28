﻿namespace AdminPortal.HaloMysql
{
    public partial class ServiceList
    {
        public int ServiceListId { get; set; }
        public string ServiceListName { get; set; }
        public string ServiceListDescription { get; set; }
    }
}
