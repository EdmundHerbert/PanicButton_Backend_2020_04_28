﻿namespace AdminPortal.HaloMysql
{
    public partial class ReferenceSubset
    {
        public int Id { get; set; }
        public string SubsetName { get; set; }
        public string SubsetPrefix { get; set; }
        public string SubsetLast { get; set; }
    }
}
