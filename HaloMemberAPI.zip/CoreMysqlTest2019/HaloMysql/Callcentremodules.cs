﻿namespace AdminPortal.HaloMysql
{
    public partial class Callcentremodules
    {
        public short CallCentreModuleId { get; set; }
        public string CallCentreModuleName { get; set; }
        public string CallCentreModuleSubNames { get; set; }
        public string CallCentreModuleHtml { get; set; }
        public string CallCentreModuleScript { get; set; }
        public int? CallCentreModuleOrder { get; set; }
    }
}
