﻿namespace AdminPortal.HaloMysql
{
    public partial class CountryList
    {
        public int CountryListId { get; set; }
        public string CountryListName { get; set; }
        public string CountryListDescription { get; set; }
    }
}
