﻿namespace AdminPortal.HaloMysql
{
    public partial class Halopartners
    {
        public long HaloPartnerId { get; set; }
        public string HaloPartnerName { get; set; }
        public string HaloPartnerLogoPath { get; set; }
        public string HaloPartnerPhoneNumbers { get; set; }
        public string HaloPartnerEmailAddress { get; set; }
        public string HaloPartnerPhysicalAddress { get; set; }
        public string HaloPartnerPostalAddress { get; set; }
        public string HaloPartnerWebsite { get; set; }
        public string HaloPartnerAbout { get; set; }
    }
}
