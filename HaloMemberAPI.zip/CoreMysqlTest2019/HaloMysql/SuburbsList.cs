﻿namespace AdminPortal.HaloMysql
{
    public partial class SuburbsList
    {
        public int SuburbsListId { get; set; }
        public string SuburbsListName { get; set; }
        public string SuburbsListDescription { get; set; }
    }
}
