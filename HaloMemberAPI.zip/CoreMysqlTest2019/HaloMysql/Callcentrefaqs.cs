﻿namespace AdminPortal.HaloMysql
{
    public partial class Callcentrefaqs
    {
        public long CallCentreFaqid { get; set; }
        public string CallCentreFaqquestion { get; set; }
        public string CallCentreFaqanswer { get; set; }
    }
}
