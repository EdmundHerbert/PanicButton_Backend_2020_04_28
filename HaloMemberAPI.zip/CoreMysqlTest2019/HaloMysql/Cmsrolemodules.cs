﻿namespace AdminPortal.HaloMysql
{
    public partial class Cmsrolemodules
    {
        public int CmsroleModuleId { get; set; }
        public short? CmsroleId { get; set; }
        public short? CmsmoduleId { get; set; }
    }
}
