﻿namespace AdminPortal.HaloMysql
{
    public partial class Halomemberloaderror
    {
        public int HaloMemberLoadErrorId { get; set; }
        public string HaloMemberLoadErrorDescription { get; set; }
        public string HaloMemberLoadErrorFtpFileName { get; set; }
        public string HaloMemberLoadErrorTimeStamp { get; set; }
        public string HaloMemberLoadErrorPolicyNumber { get; set; }
        public string HaloMemberLoadErrorMobileNumber { get; set; }
        public string HaloMemberLoadErrorName { get; set; }
        public string HaloMemberLoadErrorSurname { get; set; }
        public string HaloMemberLoadErrorIdType { get; set; }
        public string HaloMemberLoadErrorIdNumber { get; set; }
        public string HaloMemberLoadErrorEmail { get; set; }
        public string HaloMemberLoadErrorEmailSent { get; set; }
        public string HaloMemberLoadErrorDateSent { get; set; }
    }
}
